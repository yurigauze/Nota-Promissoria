function calcular() {
    var altura = document.getElementById("altura").value;
    var peso = document.getElementById("peso").value;
    var resultado;
    if (validarCampo()) {
        resultado = peso / (altura * altura);
        resultado = resultado.toFixed(2);
    }
    var divResultado = document.getElementById("resultado");
    divResultado.innerHTML = resultado;
    
}

function mostrarDados(){
    var altura = document.getElementById("altura").value;
    var peso = document.getElementById("peso").value;
    var dadosAltura = document.getElementById("dadosAltura");
    var dadosPeso = document.getElementById("dadosPeso");
    dadosAltura.innerHTML = altura;
    dadosPeso.innerHTML = peso;
}

function mudarEstado(el) {
    mostrarDados();
    var display = document.getElementById(el).style.display;
    if (display == "none")
        document.getElementById(el).style.display = 'block';
    else
        document.getElementById(el).style.display = 'none';   
}

function validarCampo(){
    var altura = document.getElementById("altura");
    var peso = document.getElementById("peso");
    if(altura.value<=0){
        altura.style.border = "1px solid red";
        return false;
    }
    if (peso.value <=0) {
        peso.style.border = "1px solid red";
        return false;
    }
    return true;
}
        .input,
        .textarea,
        .select select {
    background - color: #fff;
    border - color: #dbdbdb;
    border - radius: 4px;
    color: #363636
}